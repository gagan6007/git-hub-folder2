package com.niit.ShopB.Model1;
import java.util.List;


public interface SupplierDAO {
	
	public List<Supplier> list();
	
	public Supplier get(String sup_id);
	
	public void saveOrUpdate(Supplier supplier);
	
	public void delete(String sup_id);

}
