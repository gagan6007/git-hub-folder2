package com.niit.ShopB.Model;
import java.util.List;  


public interface CategoryDAO {

	
	public List<Category> list();
	
	public Category get(String cat_id);
	
	public void saveOrUpdate(Category category);
	
	public void delete(String cat_id);
	

}
 