package com.niit.ShopB.Model;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CategoryTest {
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.ShopB");
		context.refresh();
		
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		Category category = (Category) context.getBean("category");
		
		category.setCat_id("cg120");
		category.setCat_name("cgname123");
		category.setCat_description("cgdesc120");
		
		categoryDAO.saveOrUpdate(category);
	}

}
