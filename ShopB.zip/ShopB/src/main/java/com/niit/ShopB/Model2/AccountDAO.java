package com.niit.ShopB.Model2;
import java.util.List;


public interface AccountDAO {
           
public List<Account> list();
	
	public Account get(String u_id);
	
	public void saveOrUpdate(Account account);
	
	public void delete(String u_id);
}
