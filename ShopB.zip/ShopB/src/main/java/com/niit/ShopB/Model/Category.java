package com.niit.ShopB.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Category")
@Component
public class Category {

	
@Id	
private String	Cat_id;
private String Cat_name;
private String Cat_description;
/**
 * @return the cat_id
 */
public String getCat_id() {
	return Cat_id;
}
/**
 * @param cat_id the cat_id to set
 */
public void setCat_id(String cat_id) {
	Cat_id = cat_id;
}
/**
 * @return the cat_name
 */
public String getCat_name() {
	return Cat_name;
}
/**
 * @param cat_name the cat_name to set
 */
public void setCat_name(String cat_name) {
	Cat_name = cat_name;
}
/**
 * @return the cat_description
 */
public String getCat_description() {
	return Cat_description;
}
/**
 * @param cat_description the cat_description to set
 */
public void setCat_description(String cat_description) {
	Cat_description = cat_description;
}



}
