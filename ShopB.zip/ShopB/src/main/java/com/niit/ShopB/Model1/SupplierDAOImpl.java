package com.niit.ShopB.Model1;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("supplierDAO")
public class SupplierDAOImpl implements SupplierDAO {
   
	@Autowired
	private SessionFactory sessionFactory;
	public SupplierDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	
	
	@Transactional
	public List<Supplier> list() {
		@SuppressWarnings("unchecked")
		List<Supplier> listSupplier = (List<Supplier>)
		sessionFactory.getCurrentSession().createCriteria(Supplier.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listSupplier;
	}
    
	@Transactional
	public Supplier get(String sup_id) {
		String hql = "from supplier where id="+"'"+sup_id+"'";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Supplier> listSupplier = (List<Supplier>) query.getResultList();
		if(listSupplier != null && !listSupplier.isEmpty()){return listSupplier.get(0);}
		return null;
	}
		
		
		
	@Transactional
	public void saveOrUpdate(Supplier supplier) {
	sessionFactory.getCurrentSession().saveOrUpdate(supplier);	
		}
    
	@Transactional
	public void delete(String sup_id) {
	Supplier supplier = new Supplier();
	supplier.setSup_id(sup_id);
	sessionFactory.getCurrentSession().delete(supplier);	
	}

}
