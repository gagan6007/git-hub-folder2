package com.niit.ShopB.Model2;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Account")
@Component
public class Account {

	@Id
	private String u_id;
	private String u_email;
	private String u_name;
	private String u_pass;
	private String u_cpass;
	private String u_ph;
	private String u_addr;
	/**
	 * @return the u_id
	 */
	public String getU_id() {
		return u_id;
	}
	/**
	 * @param u_id the u_id to set
	 */
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	/**
	 * @return the u_email
	 */
	public String getU_email() {
		return u_email;
	}
	/**
	 * @param u_email the u_email to set
	 */
	public void setU_email(String u_email) {
		this.u_email = u_email;
	}
	/**
	 * @return the u_name
	 */
	public String getU_name() {
		return u_name;
	}
	/**
	 * @param u_name the u_name to set
	 */
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	/**
	 * @return the u_pass
	 */
	public String getU_pass() {
		return u_pass;
	}
	/**
	 * @param u_pass the u_pass to set
	 */
	public void setU_pass(String u_pass) {
		this.u_pass = u_pass;
	}
	/**
	 * @return the u_cpass
	 */
	public String getU_cpass() {
		return u_cpass;
	}
	/**
	 * @param u_cpass the u_cpass to set
	 */
	public void setU_cpass(String u_cpass) {
		this.u_cpass = u_cpass;
	}
	/**
	 * @return the u_pg
	 */
	public String getU_ph() {
		return u_ph;
	}
	/**
	 * @param u_pg the u_pg to set
	 */
	public void setU_ph(String u_ph) {
		this.u_ph = u_ph;
	}
	/**
	 * @return the u_addr
	 */
	public String getU_addr() {
		return u_addr;
	}
	/**
	 * @param u_addr the u_addr to set
	 */
	public void setU_addr(String u_addr) {
		this.u_addr = u_addr;
	}
	
	
	
	
}
