package com.niit.ShopB.Model1;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class SupplierTest {

	public static void main(String[] args) {
		
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	context.scan("com.niit.ShopB");
	context.refresh();
	
	SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
	Supplier supplier = (Supplier) context.getBean("supplier");
	
	supplier.setSup_id("sp121");;
	supplier.setSup_name("spSANGEETHA");
	supplier.setSup_addr("no#21/22 4th cross 4th main kp west bng-08");
	
	supplierDAO.saveOrUpdate(supplier);
		
	}
	
}
