package com.niit.ShopB.Model3;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class ProductTest {
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.ShopB");
        context.refresh();
        
        ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		 Product product = (Product) context.getBean("product");
		 
		 product.setPro_id("pr2");
		 product.setPro_name("SAMSUNG S8");
		 product.setPro_features("7inch LCD display,TouchScreen,wifi,blueooth, 8gd built-in-memory expandable upto32gb");
		 product.setPro_price(30000);
		 
		 productDAO.saveOrUpdate(product);
	}

}
