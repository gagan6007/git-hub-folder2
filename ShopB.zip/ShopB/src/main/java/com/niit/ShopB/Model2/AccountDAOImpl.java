package com.niit.ShopB.Model2;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;




@Repository("accountDAO")
public class AccountDAOImpl implements AccountDAO {
    
	@Autowired
	private SessionFactory sessionFactory;
	public AccountDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Account> list() {
		@SuppressWarnings("unchecked")
		List<Account> listAccount = (List<Account>)
		sessionFactory.getCurrentSession().createCriteria(Account.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listAccount;
		}

	
	@Transactional
	public Account get(String u_id) {
		String hql = "from account where id="+"'"+u_id+"'";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Account> listAccount = (List<Account>) query.getResultList();
		if(listAccount != null && !listAccount.isEmpty()){return listAccount.get(0);}
		return null;
		
	}

	
	@Transactional
	public void saveOrUpdate(Account account) {
		/*sessionFactory.getCurrentSession().saveOrUpdate(account);*/
		if((account.getU_pass()).equals(account.getU_cpass()))
		{sessionFactory.getCurrentSession().saveOrUpdate(account);} 
		else
        {System.out.println("Password does not match.Please Enter Correct Password");}
	}
    
	
	@Transactional
	public void delete(String u_id) {
		Account account = new Account();
		account.setU_id(u_id);
		sessionFactory.getCurrentSession().delete(account);	
		
	}

}
