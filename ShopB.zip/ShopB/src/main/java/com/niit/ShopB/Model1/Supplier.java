package com.niit.ShopB.Model1;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Supplier")
@Component
public class Supplier {

	@Id
	private String sup_id;
	private String sup_name;
	private String sup_addr;
	/**
	 * @return the sup_id
	 */
	public String getSup_id() {
		return sup_id;
	}
	/**
	 * @param sup_id the sup_id to set
	 */
	public void setSup_id(String sup_id) {
		this.sup_id = sup_id;
	}
	/**
	 * @return the sup_name
	 */
	public String getSup_name() {
		return sup_name;
	}
	/**
	 * @param sup_name the sup_name to set
	 */
	public void setSup_name(String sup_name) {
		this.sup_name = sup_name;
	}
	/**
	 * @return the sup_addr
	 */
	public String getSup_addr() {
		return sup_addr;
	}
	/**
	 * @param sup_addr the sup_addr to set
	 */
	public void setSup_addr(String sup_addr) {
		this.sup_addr = sup_addr;
	}
	
	
	
	
}
