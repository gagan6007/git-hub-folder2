package com.niit.ShopB.Model2;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class AccountTest {
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.ShopB");
		context.refresh();
		
		AccountDAO accountDAO = (AccountDAO) context.getBean("accountDAO");
		 Account account = (Account) context.getBean("account");
		 
		 account.setU_id("user111");
		 account.setU_email("gagan@gmail.com");
		 account.setU_name("gaaagln");
		 account.setU_pass("18");
		 account.setU_cpass("188");
		 account.setU_ph("9066115586");
		 account.setU_addr("no#21/22 4thmain 4thcross kpwest bng-08");
		 
		 accountDAO.saveOrUpdate(account);
		
	}

}
