package com.niit.ShopB.Model3;
import java.util.List;


public interface ProductDAO {
	
public List<Product> list();
	
	public Product get(String pro_id);
	
	public void saveOrUpdate(Product product);
	
	public void delete(String pro_id);

}
